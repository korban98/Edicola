import java.util.Scanner;

import bean.Quotidiano;

public class EdicolaTest {
    public static void main(String[] args) throws Exception {
        char termina = 'N';
        int select;
        boolean errore = false, aperto = true;

        Scanner inputString = new Scanner(System.in);
        Scanner inputNum = new Scanner(System.in);

        while (aperto) {
            do {
                System.out.println("MENU:");
        	System.out.println("1. Inserisci");
        	System.out.println("2. Modifica");
        	System.out.println("3. Rimuovi pubb. terminate");
        	System.out.println("4. Chiudi\n");
        	System.out.print("Scegli una voce dal menu': ");
                select = inputNum.nextInt(); 
                System.out.println();
            } while(select < 1 || select > 4);

            switch(select) {
                case 1:
                    do {
                        Quotidiano nuovaPubblicazione = new Quotidiano();
            
                        System.out.print("Inserire nome pubblicazione (almeno 3 caratteri): ");
                        nuovaPubblicazione.setNome(inputString.nextLine());
                        System.out.print("Inserire quantità di copie ricevute: ");
                        nuovaPubblicazione.setCopieRicevute(inputString.nextLine());
                        System.out.print("Inserire prezzo di copertina: ");
                        nuovaPubblicazione.setPrezzo(inputString.nextLine());
                        System.out.print("Inserire percentuale di aggio (da 5% a 20%): ");
                        nuovaPubblicazione.setAggio(inputString.nextLine());
                        System.out.print("Inserire quantità di copie vendute: ");
                        nuovaPubblicazione.setCopieVendute(inputString.nextLine());
            
                        //insert
            
                        do {
                            if(errore) System.out.println("\nERRORE: i valori ammessi sono S/N");
                            System.out.print("\nVuoi inserire un'altra pubblicazione (S/N)? ");
                            termina = inputString.nextLine().charAt(0);
                            errore = true;
                        } while(termina != 'N' && termina != 'S');
                        errore = false;
                        System.err.println();
                    } while(termina != 'N');
                    System.out.println("RESOCONTO ATTUALE:");
                    miaEdicola.printResoconto();
                    break;
                case 2:
                    //update copie vendute
                    break;
                case 3:
                    //update prezzo
                    break;
                case 4:
                    //update aggio
                    break;
                default:
                    break;
            }
        }

        inputNum.close();
        inputString.close();
        System.exit(0);
    }
}